#ifndef TASK_1_HPP
#define TASK_1_HPP

#include <vector>

int count_max_odd(const std::vector<int>& nums);

#endif